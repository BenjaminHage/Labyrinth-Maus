# Yet Another Robot

Modular robot platform

# Projects based off YAR

- White YAR: Maze solving robot, project by Benjamin Hage
