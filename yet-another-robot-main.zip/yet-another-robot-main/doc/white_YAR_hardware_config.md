# YAR - Yet Another Robot

## WHITE YAR "maze solver" hardware configuration

### components

#### motors

- Pololu 50:1 micro metal gear motor HPCB 6V with 12 CPR encoder, part #5187 (https://www.pololu.com/product/5187)

#### motor controller

- Pololu Motoron M1T550 singel I2C motor controller, part #5074 (https://www.pololu.com/product/5074)

#### wheels

- Pololu 40x7mm wheel, part #1452 (https://www.pololu.com/product/1452)

#### power supply

- Waveshare UPS module 3S Li-Ion, 5V / 5A output, part #23884 (https://www.waveshare.com/ups-module-3s.htm)

#### additional hardware

- Pololu breakout board for JST SH style connector, 6 pin, part #4770 (https://www.pololu.com/product/4770)
- Pololu JST SH style cable 10 cm, 6 pin, part #4765 (https://www.pololu.com/product/4765)
- Screw M2x8 (8x)
- Screw M3x20 (12x)
- Nut M2 (4x)
- Heat insert M2 (4x)
- Nut M3 (20x)

#### battery

- Panasonic NCR18650BD 3.6V / 3200 mAh Li-Ion battery

#### MCU

- Raspberry Pi 3
- 8CH 18Bit Differentrial A/D converter HAT (https://www.abelectronics.co.uk/p/65/adc-differential-pi)

#### IR sensors

- Pololu GP2Y0A51SK0F analog distance sensor 2-15cm (https://www.pololu.com/product/2450)

### assembly

For maximum flexibility during prototyping, the individual components are mounted to a breadboard and shall be connected using breadboard jumper wires.

- motor &rarr; SH cable &rarr; SH breakout board &rarr; pin header

- pin header &rarr; motor controller &rarr; pin header

### hardware assembly

![](./images/motor_mount_annotated.png)

![](./images/drive_module_bottom_view_annotated.png)

![](./images/drive_module_annotated.png)



